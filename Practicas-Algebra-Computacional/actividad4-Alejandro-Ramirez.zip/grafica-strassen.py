import random as rnd
import strassen as st
import matplotlib.pyplot as plt
import time
import math

mindigs = 2
maxdigs = 200
digstep = 1

numdigs = []
tiempos = []

n = mindigs
while n <= maxdigs:
    A = [] * n
    B = [] * n
    for i in range(n):
        A.append([0]*n)
        B.append([0]*n)
        for j in range(n):
            A[i][j] = rnd.randint(0,9)
            B[i][j] = rnd.randint(0,9)      
    ini = time.thread_time()
    C = st.mult_strassen(A,B)
    fin = time.thread_time()
    
    numdigs += [n]
    t = fin-ini
    tiempos += [t]
    n += digstep
    
plt.plot(numdigs, tiempos, "b-")
plt.xlabel('número de dígitos')
plt.ylabel('tiempo [seg]')
plt.savefig("strassen-tiempos.png")