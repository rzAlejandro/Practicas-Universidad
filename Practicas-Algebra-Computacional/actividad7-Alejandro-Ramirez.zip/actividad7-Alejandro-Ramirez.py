# -*- coding: utf-8 -*-
"""
Created on Tue Nov  9 17:45:27 2021

@author: aleja
"""
import random
import json
import matplotlib.pyplot as plt

def multiplicar_mod (a , b , N ): # 0 <= a,b < N, N >= 1
    c = a * b
    c %= N
    return c

def dec_to_binario(n):
    s = []
    x = n
    while x>0:
        s.append(x%2)
        x = x//2
    return s

def potencia_mod_iter (a , k , N ): # 0 <= a < N, k >= 0 , N >= 2
    l = dec_to_binario(k) #Pasamos k a binario 
    i = len(l)-1
    r = 1
    while i>=0: #Recorremos k desde bit más significativo a menos significativo
        r = multiplicar_mod(r, r, N)
        if l[i] == 1:
            r = multiplicar_mod(a,r,N)
        i-=1
    return r

def gcd(a, b) :
    if (a < b) :
        return gcd(b,a)
    if (a % b == 0) :
        return b
    return gcd(b, a % b)


def jacobi_cb2(n):
    r = 1
    if n%8==3 or n%8 == 5:
        r = -1
    return r

def jacobi_iter(a,n):
    r = 1
    while a > 1:
        a = a%n
        if a%2 == 0:
            a = a//2
            r*=jacobi_cb2(n)
        else: #Aplicar ley de reciprocidad cuadratica
            if a%4 == 3 and n%4 == 3:
                r*=-1
            a,n = n,a
    return r         
        
def test_Solovay_Strassen(n,k): 
    while k>0:
        a = random.randint(1,n-1)
        t1 = gcd(a,n)
        if t1 == 1: #Primera parte del test
            #Hallar a^(n-1/2) mod n con la funcion potencia_mod
            t2 = potencia_mod_iter(a,(n-1)//2,n)
            t3 = jacobi_iter(a,n)
            if ((t2 - t3)%n) != 0: 
                return False
        else:
            return False
        k-=1
    return True

def generar_numero_base(k):
    d = random.randint(1, 9)
    n = d
    k-=1
    while k>0:
        d = random.randint(0, 9)
        n = n*10 + d
        k -= 1
    return n

def generar_primos(n,k):
    cont = 0
    encontrado = False
    while not encontrado:
        p = generar_numero_base(n)
        if p%2 != 0: #p par no puede ser posible primo
            encontrado = test_Solovay_Strassen(p,k)
        cont += 1
    return (p,cont)

def generar_datos():
    datos = {} #Diccionario {int : int} clave: contador; valor: frecuencia
    for i in range(100): #Llamamos 100 veces a generar_primos y añadimos frecuencias
        (p,c) = generar_primos(300,20)
        if c in datos.keys():
            datos[c] += 1
        else:
            datos[c] = 1
    #Guardamos datos en json para ejecutar una única vez
    #Así pruebo diferentes histogramas más rápido
    with open('data.json', 'w') as file: 
        json.dump(datos, file, indent=4)
    
def generar_histograma():
    #generar_datos()
    with open('data.json') as file: #Extraemos los datos del json
        datos = json.load(file)
    
    lista = []
    cmax = 0
    for c in datos.keys():
        for k in range(datos[c]):
            lista.append(int(c))
        if int(c) > cmax:
            cmax = int(c)
    plt.title('Histograma del test de Solovay-Strassen')
    plt.hist(x = lista, rwidth = 0.85,bins = 50) #bins es el nº de intervalos
    plt.xlabel("Contador")
    plt.ylabel("Frecuencia")
    plt.savefig('histograma.png')
    
#print(generar_primos(1000, 100)) 
#generar_histograma()